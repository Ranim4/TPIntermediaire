package com.formation.TPFormationFavManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpFormationFavManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpFormationFavManagerApplication.class, args);
	}

}
